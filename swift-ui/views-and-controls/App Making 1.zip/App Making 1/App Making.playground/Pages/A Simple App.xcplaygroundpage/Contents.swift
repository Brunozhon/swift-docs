/*:
 # Project: A simple app
 
 1. Enter this code:
 ```
import SwiftUI
struct MyStruct: View {
    var body: some View {
        VStack {
            Text("Hello world!")
        }
    }
}
 ```
 2. Add the `.title` font to the first `Text`.
 ```
Text("Hello world!")
    .font(.title)
 ```
 3. Add a second `Text` with anything you want.
 */









/*:
 - Note: In case you noticed you can't copy text, you shouldn't be copying text. You can use your own shortcut bar at the bottom of your screen ⬇️.
 
 This project and all other projects are optional, so if you don't want to do it or are finished, go click "Next."
 
 [Next](@next)
 */
/*:
 
 If you want to display your text, replace the placeholder with `MyStruct()`.
 */
import PlaygroundSupport
// PlaygroundPage.current.setLiveView(<#MyStruct#>) // Uncomment this first.

/*:
 # Before we start
 
 This playground assumes that you have some knowledge of Swift. This includes:
 
 1. Variables
 2. Types
 3. Structs and Classes
 4. Functions
 5. Modules
 
 Try them out in this workspace before moving on.
 */












//: When you're ready, move on to the [next page.](@next)

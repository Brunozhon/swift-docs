//: Let's introduce a module called `SwiftUI`.
import SwiftUI
/*:
 SwiftUI can make code like this:
 ```
struct MyView: View {
    var body: some View {
        Text("Hello world!")
    }
}
 ```
 */
/*:
 
 Let's get started! [Over to the next page!](@next)
 */
